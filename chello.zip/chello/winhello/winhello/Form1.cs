﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winhello
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            //通过点击实际完成数据的添加显示
            showMsg();
        }
        void showMsg()
        {
            //向文本控件中添加HelloWorld
            textBox1.AppendText("Hello World!" + "\t\n");
        }
    }
}
